=== MB Social Sharing Plugin ===
Contributors: moumitab0027
Tags: Facebook share, Twitter share, GooglePlus share, Linkedin share, Pinterest share, Digg share, Reddit share
Requires at least: 3.5
Tested up to: 5.1.1
Stable tag: 1.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


MB Social sharing is a simple social share buttons of Facebook, Twitter, GooglePlus, Linkedin, Pinterest, Digg, Reddit.

== Description ==
It is a social share button plugin. Using this plugin you can easily manage the social share buttons.
You just use this shortcode [mb_social_share label="Social Sharing"  link="www.google.com" content="This is social sharing plugin"] whatever you want to use social share buttons. You just put your sharing link, content and label.

== Plugin Shortcode ==
You just use this shortcode [mb_social_share label="Social Sharing"  link="www.google.com" content="This is social sharing plugin"] whatever you want to use social share buttons. You just put your sharing link, content and label.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the Social Sharing Settings Name screen to configure the plugin.



