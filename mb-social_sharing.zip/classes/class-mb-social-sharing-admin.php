<?php
class MB_Social_Sharing_Admin {
  
  public $settings;

	public function __construct() {

		$this->load_class('settings');
		$this->settings = new MB_Social_Sharing_Settings();
	}

	function load_class($class_name = '') {
	  global $MB_Social_Sharing;
		if ('' != $class_name) {
			require_once ($MB_Social_Sharing->plugin_path . '/admin/class-' . esc_attr($MB_Social_Sharing->token) . '-' . esc_attr($class_name) . '.php');
		} // End If Statement
	}// End load_class()
	
}