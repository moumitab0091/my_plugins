<?php
class MB_Social_Share {

	public function __construct() {

	}

	/**
	 * Output the demo shortcode.
	 *
	 * @access public
	 * @param array $atts
	 * @return void
	 */
	public function output( $attr ) {
		global $MB_Social_Sharing;
		$MB_Social_Sharing->nocache();

		$link = 'www.google.com';
		$label = 'social_share';
		$content = 'This is demo social share content';

		$label = apply_filters( 'mb_social_share_label', $label );
		$link = apply_filters( 'mb_social_share_link', $link );
		$content = apply_filters( 'mb_social_share_content', $content );

		$social_share_settings = get_option('mb_mb_social_sharing_general_settings_name');
		
		echo '<div class="social">';
			if($social_share_settings['mb_enable_facebook'] == 1){
				echo '<!--Facebook-->
		        <a style="color: #fff;" class="facebook" href="http://www.facebook.com/sharer.php?u='. $link .'&t='. $content .'" rel="nofollow" title="Share this post on Facebook!" onclick="window.open(this.href); return false;">Facebook</a>';
			}	
			
			if($social_share_settings['mb_enable_google'] == 1){	
			    echo '<!--Google Plus-->
			        <a style="color: #fff;" class="google-plus" target="_blank" href="https://plus.google.com/share?url='. $link .'" rel="nofollow">Google+</a>';
		    }
			
			if($social_share_settings['mb_enable_twitter'] == 1){	
				echo '<!--Twitter-->
			        <a style="color: #fff;" class="twitter" href="https://twitter.com/intent/tweet?text='.$content.'&url='. $link .'" title="Share this post on Twitter!" target="_blank" rel="nofollow">Twitter</a>';
		    }

			if($social_share_settings['mb_enable_reddit'] == 1){				
				echo '<!--Reddit-->
					<a style="color: #fff;" class="reddit" target="_blank" href="http://reddit.com/submit?url='. $link .'&amp;title='. $content .'" rel="nofollow">Reddit</a>';
			}

			if($social_share_settings['mb_enable_digg'] == 1){	
				echo '<!--Digg-->
					<a style="color: #fff;" class="digg" target="_blank" href="https://digg.com/submit?url='. $link .'&amp;title='. $content .'" rel="nofollow">&nbsp;&nbsp;Digg&nbsp;&nbsp;</a>';
			}
				
			if($social_share_settings['mb_enable_linkedin'] == 1){	
				echo '<!--LinkedIn-->
					<a style="color: #fff;" class="linkedin" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url='. $link .'" rel="nofollow">LinkedIn</a>';
			}

			if($social_share_settings['mb_enable_pinterst'] == 1){	
				echo '<!--Pinterst-->
					<a style="color: #fff;" class="pinterest" target="_blank" href="http://pinterest.com/pin/create/bookmarklet/?url='. $link .'&is_video=false&description='. $content .'" rel="nofollow">Pinterest</a>';
			}
		echo '</div>';


	}
}
