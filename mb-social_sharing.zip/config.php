<?php

define('MB_SOCIAL_SHARING_PLUGIN_TOKEN', 'mb-social-sharing');

define('MB_SOCIAL_SHARING_TEXT_DOMAIN', 'social_sharing');

define('MB_SOCIAL_SHARING_PLUGIN_VERSION', '1.0.0');
?>